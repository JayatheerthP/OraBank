package com.jayatheerth.userservice.service;

import java.util.UUID;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jayatheerth.userservice.dto.UserResponse;
import com.jayatheerth.userservice.dto.UserSignInRequest;
import com.jayatheerth.userservice.dto.UserSignInResponse;
import com.jayatheerth.userservice.dto.UserSignUpRequest;
import com.jayatheerth.userservice.dto.UserSignUpResponse;
import com.jayatheerth.userservice.dto.UserStatusResponse;
import com.jayatheerth.userservice.entity.User;
import com.jayatheerth.userservice.exception.UserErrorType;
import com.jayatheerth.userservice.exception.UserServiceException;
import com.jayatheerth.userservice.repository.UserRepository;
import com.jayatheerth.userservice.security.JWTService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JWTService jwtService;

    @Override
    public UserSignUpResponse signUp(UserSignUpRequest request) {
        logger.debug("Processing signup for email: {}", request.getEmail());
        // Check if user already exists by email
        if (userRepository.existsByEmail(request.getEmail())) {
            logger.error("Signup failed: User already exists with email: {}", request.getEmail());
            throw new UserServiceException(UserErrorType.USER_ALREADY_EXISTS);

        }

        // Map request to User entity
        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword())); // Encode the password
        user.setPhoneNumber(request.getPhoneNumber());
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setDateOfBirth(request.getDateOfBirth());
        user.setAddress(request.getAddress());
        user.setIsActive(true); // Default to active
        user.setIsLocked(false); // Default to not locked
        user.setFailedLoginAttempts(0); // Initialize failed login attempts

        // Save user to database
        User savedUser = userRepository.save(user);
        logger.info("User successfully saved with userId: {}", savedUser.getUserId());

        // Map saved user to response DTO
        return new UserSignUpResponse(
                savedUser.getUserId(),
                savedUser.getEmail(),
                savedUser.getFirstName(),
                savedUser.getLastName(),
                savedUser.getIsActive(),
                savedUser.getIsLocked(),
                savedUser.getCreatedAt());
    }

    @Override
    public UserSignInResponse signIn(UserSignInRequest request) {
        logger.debug("Processing signin for email: {}", request.getEmail());
        // Find user by email
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    logger.error("Signin failed: User not found with email: {}", request.getEmail());
                    return new UserServiceException(UserErrorType.USER_NOT_FOUND);
                });

        // Verify password
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            // Increment failed login attempts
            user.setFailedLoginAttempts(user.getFailedLoginAttempts() + 1);
            // Optionally lock account after a threshold (e.g., 5 failed attempts)
            if (user.getFailedLoginAttempts() >= 5) {
                user.setIsLocked(true);
                logger.warn("Account locked for userId: {} due to too many failed attempts", user.getUserId());
            }
            userRepository.save(user);
            logger.error("Signin failed: Invalid credentials for email: {}", request.getEmail());
            throw new UserServiceException(UserErrorType.INVALID_CREDENTIALS);
        }

        // Check if account is locked
        if (user.getIsLocked()) {
            logger.error("Signin failed: Account locked for email: {}", request.getEmail());
            throw new UserServiceException(UserErrorType.ACCOUNT_LOCKED);
        }

        // Reset failed login attempts on successful login
        user.setFailedLoginAttempts(0);
        userRepository.save(user);

        // Generate JWT token
        String token = jwtService.generateToken(user.getUserId());
        logger.info("Signin successful for userId: {}, token generated", user.getUserId());

        // Return sign-in response with token and expiration time
        return new UserSignInResponse(token, user.getUserId(), jwtService.getExpirationTime());
    }

    @Override
    public UserResponse getUser(UUID userId) {
        logger.debug("Fetching user details for userId: {}", userId);
        // Find user by ID
        User user = userRepository.findById(userId)
                .orElseThrow(() -> {
                    logger.error("User not found with userId: {}", userId);
                    return new UserServiceException(UserErrorType.USER_NOT_FOUND);
                });

        logger.info("User details retrieved for userId: {}", userId);

        // Map user entity to response DTO
        return new UserResponse(
                user.getUserId(),
                user.getEmail(),
                user.getPhoneNumber(),
                user.getFirstName(),
                user.getLastName(),
                user.getDateOfBirth(),
                user.getAddress(),
                user.getIsActive(),
                user.getIsLocked(),
                user.getCreatedAt());
    }

    @Override
    public UserStatusResponse getStatus(UUID userId) {
        // Find user by ID
        logger.debug("Fetching user status for userId: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> {
                    logger.error("User not found with userId: {}", userId);
                    return new UserServiceException(UserErrorType.USER_NOT_FOUND);
                });

        logger.info("User status retrieved for userId: {}", userId);

        // Map user entity to status response DTO
        return new UserStatusResponse(
                user.getUserId(),
                user.getIsActive(),
                user.getIsLocked(),
                user.getFailedLoginAttempts());
    }

}
