package com.jayatheerth.userservice.service;

import java.util.UUID;

import com.jayatheerth.userservice.dto.UserResponse;
import com.jayatheerth.userservice.dto.UserSignInRequest;
import com.jayatheerth.userservice.dto.UserSignInResponse;
import com.jayatheerth.userservice.dto.UserSignUpRequest;
import com.jayatheerth.userservice.dto.UserSignUpResponse;
import com.jayatheerth.userservice.dto.UserStatusResponse;

public interface UserService {

    UserSignUpResponse signUp(UserSignUpRequest request);

    UserSignInResponse signIn(UserSignInRequest request);

    UserResponse getUser(UUID userId);

    UserStatusResponse getStatus(UUID userId);

}
