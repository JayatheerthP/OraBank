package com.jayatheerth.userservice.exception;

import org.springframework.http.HttpStatus;

public enum UserErrorType {

    USER_ALREADY_EXISTS("User with this email already exists", HttpStatus.CONFLICT),
    USER_NOT_FOUND("User not found", HttpStatus.NOT_FOUND),
    INVALID_CREDENTIALS("Invalid email or password", HttpStatus.UNAUTHORIZED),
    ACCOUNT_LOCKED("Account is locked", HttpStatus.FORBIDDEN),
    INVALID_INPUT("Invalid input data", HttpStatus.BAD_REQUEST);

    private final String message;
    private final HttpStatus httpStatus;

    UserErrorType(String message, HttpStatus httpStatus) {
        this.message = message;
        this.httpStatus = httpStatus;
    }

    public String getMessage() {
        return message;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}