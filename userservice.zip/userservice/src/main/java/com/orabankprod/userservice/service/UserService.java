package com.orabankprod.userservice.service;

import com.orabankprod.userservice.dto.UserLogoutResponse;
import com.orabankprod.userservice.dto.UserResponse;
import com.orabankprod.userservice.dto.UserSignInRequest;
import com.orabankprod.userservice.dto.UserSignInResponse;
import com.orabankprod.userservice.dto.UserSignupRequest;
import com.orabankprod.userservice.dto.UserSignupResponse;

public interface UserService {
    UserSignupResponse createUser(UserSignupRequest request);

    UserSignInResponse signIn(UserSignInRequest request);

    UserLogoutResponse signOut();

    UserResponse getCurrentUser();
}
