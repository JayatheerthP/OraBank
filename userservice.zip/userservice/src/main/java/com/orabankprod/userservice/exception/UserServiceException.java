package com.orabankprod.userservice.exception;

public class UserServiceException extends RuntimeException {
    private final UserErrorType errorType;

    public UserServiceException(UserErrorType errorType) {
        this.errorType = errorType;
    }

    public UserErrorType getErrorType() {
        return errorType;
    }
}