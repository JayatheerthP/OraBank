package com.orabankprod.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class UserSignInResponse {
    private String token;
    private String fullname;
    private String email;
    private String role;
}
