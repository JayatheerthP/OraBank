package com.orabankprod.userservice.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.orabankprod.userservice.dto.UserLogoutResponse;
import com.orabankprod.userservice.dto.UserResponse;
import com.orabankprod.userservice.dto.UserSignInRequest;
import com.orabankprod.userservice.dto.UserSignInResponse;
import com.orabankprod.userservice.dto.UserSignupRequest;
import com.orabankprod.userservice.dto.UserSignupResponse;
import com.orabankprod.userservice.entity.User;
import com.orabankprod.userservice.exception.UserErrorType;
import com.orabankprod.userservice.exception.UserServiceException;
import com.orabankprod.userservice.repository.UserRepository;
import com.orabankprod.userservice.security.JwtService;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {

    private static final short MAX_FAILED_ATTEMPTS = 5;
    private static final int LOCK_MINUTES = 15;

    @Autowired
    UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Override
    public UserSignupResponse createUser(UserSignupRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserServiceException(UserErrorType.EMAIL_ALREADY_EXISTS);
        }
        User user = User.builder()
                .fullname(request.getFullname())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .phoneNumber(request.getPhoneNumber())
                .isActive(true)
                .role(request.getRole())
                .failedLoginCount((short) 0)
                .build();

        userRepository.save(user);

        return new UserSignupResponse(
                user.getId(),
                user.getFullname(),
                user.getEmail(),
                user.getRole());
    }

    @Override
    @Transactional(dontRollbackOn = UserServiceException.class)
    public UserSignInResponse signIn(UserSignInRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UserServiceException(UserErrorType.INVALID_CREDENTIALS));

        // Account lock check
        if (user.getLockUntil() != null && user.getLockUntil().isAfter(LocalDateTime.now())) {
            throw new UserServiceException(UserErrorType.ACCOUNT_LOCKED);
        }

        // Inactive account check
        if (!Boolean.TRUE.equals(user.getIsActive())) {
            throw new UserServiceException(UserErrorType.ACCOUNT_INACTIVE);
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            short failedLoginCount = (short) ((user.getFailedLoginCount() == null ? 0 : user.getFailedLoginCount())
                    + 1);
            user.setFailedLoginCount(failedLoginCount);
            user.setLastFailedLoginAt(LocalDateTime.now());

            if (failedLoginCount >= MAX_FAILED_ATTEMPTS) {
                user.setLockUntil(LocalDateTime.now().plusMinutes(LOCK_MINUTES));
            }
            userRepository.save(user);
            throw new UserServiceException(UserErrorType.INVALID_CREDENTIALS);
        }

        // Successful login: reset failed count, update timestamps, clear lock
        user.setFailedLoginCount((short) 0);
        user.setLastLoginAt(LocalDateTime.now());
        user.setLockUntil(null);
        userRepository.save(user);

        // Generate JWT token and build response
        String token = jwtService.generateToken(user);
        return new UserSignInResponse(
                token,
                user.getFullname(),
                user.getEmail(),
                user.getRole());
    }

    @Override
    public UserLogoutResponse signOut() {
        return new UserLogoutResponse("Logout successful.");
    }

    @Override
    public UserResponse getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new UserServiceException(UserErrorType.UNAUTHORIZED);
        }
        String email = (String) authentication.getPrincipal();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserServiceException(UserErrorType.USER_NOT_FOUND));

        return new UserResponse(
                user.getId(),
                user.getFullname(),
                user.getEmail(),
                user.getPhoneNumber(),
                user.getRole(),
                user.getIsActive());
    }
}
