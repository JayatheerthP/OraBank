package com.orabankprod.userservice.exception;

public enum UserErrorType {
    INVALID_CREDENTIALS,
    ACCOUNT_LOCKED,
    ACCOUNT_INACTIVE,
    EMAIL_ALREADY_EXISTS,
    UNAUTHORIZED,
    USER_NOT_FOUND
}