package com.orabankprod.userservice.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.orabankprod.userservice.dto.UserLogoutResponse;
import com.orabankprod.userservice.dto.UserResponse;
import com.orabankprod.userservice.dto.UserSignInRequest;
import com.orabankprod.userservice.dto.UserSignInResponse;
import com.orabankprod.userservice.dto.UserSignupRequest;
import com.orabankprod.userservice.dto.UserSignupResponse;
import com.orabankprod.userservice.service.UserService;

import jakarta.annotation.security.PermitAll;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/signup")
    @ResponseStatus(HttpStatus.CREATED)
    public UserSignupResponse createUser(@Valid @RequestBody UserSignupRequest request) {
        return userService.createUser(request);
    }

    @PermitAll
    @PostMapping("/signin")
    @ResponseStatus(HttpStatus.OK)
    public UserSignInResponse signIn(@Valid @RequestBody UserSignInRequest request) {
        return userService.signIn(request);
    }

    @PostMapping("/signout")
    @ResponseStatus(HttpStatus.OK)
    public UserLogoutResponse signOut() {
        return userService.signOut();
    }

    @GetMapping("/me")
    public UserResponse getCurrentUser() {
        return userService.getCurrentUser();
    }
}