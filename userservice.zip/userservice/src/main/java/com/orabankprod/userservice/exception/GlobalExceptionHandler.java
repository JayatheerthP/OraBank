package com.orabankprod.userservice.exception;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private final MessageSource messageSource;

    public GlobalExceptionHandler(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @ExceptionHandler(UserServiceException.class)
    public ResponseEntity<?> handleUserServiceException(UserServiceException ex) {
        String code = "user.error." + ex.getErrorType();
        String message = messageSource.getMessage(
                code, null, "User service error", LocaleContextHolder.getLocale());

        int status = switch (ex.getErrorType()) {
            case INVALID_CREDENTIALS, UNAUTHORIZED -> 401;
            case ACCOUNT_LOCKED -> 423;
            case ACCOUNT_INACTIVE -> 403;
            case EMAIL_ALREADY_EXISTS -> 409;
            case USER_NOT_FOUND -> 404;
        };

        return ResponseEntity.status(status).body(message);
    }
}