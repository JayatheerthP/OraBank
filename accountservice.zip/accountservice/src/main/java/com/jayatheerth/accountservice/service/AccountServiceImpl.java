package com.jayatheerth.accountservice.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jayatheerth.accountservice.dto.AccountBalanceResponse;
import com.jayatheerth.accountservice.dto.AccountCreateRequest;
import com.jayatheerth.accountservice.dto.AccountCreateResponse;
import com.jayatheerth.accountservice.dto.AccountResponse;
import com.jayatheerth.accountservice.dto.AccountUserResponse;
import com.jayatheerth.accountservice.entity.Account;
import com.jayatheerth.accountservice.exception.AccountErrorType;
import com.jayatheerth.accountservice.exception.AccountServiceException;
import com.jayatheerth.accountservice.repository.AccountRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AccountServiceImpl implements AccountService {
    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);
    private final AccountRepository accountRepository;

    @Override
    public AccountCreateResponse createAccount(AccountCreateRequest request) {
        logger.info("Processing account creation for userId: {}", request.getUserId());
        logger.debug("Account creation request details: type={}, currency={}, initialDeposit={}",
                request.getAccountType(), request.getCurrency(), request.getInitialDeposit());

        // Generate a unique account number using UUID
        String accountNumber = UUID.randomUUID().toString();
        logger.debug("Generated account number (UUID): {}", accountNumber);

        // Check if account number already exists (unlikely with UUID, but as a
        // safeguard)
        if (accountRepository.existsByAccountNumber(accountNumber)) {
            logger.error("Account creation failed: Generated account number already exists: {}", accountNumber);
            throw new AccountServiceException(AccountErrorType.ACCOUNT_ALREADY_EXISTS);
        }

        // Map request to Account entity
        Account account = new Account();
        account.setUserId(request.getUserId());
        account.setAccountNumber(accountNumber);
        account.setAccountType(request.getAccountType());
        account.setBalance(request.getInitialDeposit());
        account.setCurrency(request.getCurrency());
        account.setIsActive(true); // Default to active
        account.setIsLocked(false); // Default to not locked

        // Save account to database
        Account savedAccount = accountRepository.save(account);
        logger.info("Account successfully created with accountId: {} for userId: {}",
                savedAccount.getAccountId(), savedAccount.getUserId());

        // Map saved account to response DTO
        return new AccountCreateResponse(
                savedAccount.getAccountId(),
                savedAccount.getAccountNumber(),
                savedAccount.getAccountType(),
                savedAccount.getBalance(),
                savedAccount.getCurrency(),
                savedAccount.getIsActive(),
                savedAccount.getIsLocked(),
                savedAccount.getCreatedAt());
    }

    @Override
    public AccountResponse getAccount(UUID accountId) {
        logger.info("Fetching account details for accountId: {}", accountId);
        logger.debug("Processing request to retrieve account with accountId: {}", accountId);

        // Find account by ID
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> {
                    logger.error("Account not found with accountId: {}", accountId);
                    return new AccountServiceException(AccountErrorType.ACCOUNT_NOT_FOUND);
                });

        logger.info("Account details retrieved for accountId: {}", accountId);

        // Map account entity to response DTO
        return new AccountResponse(
                account.getAccountId(),
                account.getUserId(),
                account.getAccountNumber(),
                account.getAccountType(),
                account.getBalance(),
                account.getCurrency(),
                account.getIsActive(),
                account.getIsLocked(),
                account.getCreatedAt());
    }

    @Override
    public AccountUserResponse getUserAccounts(UUID userId) {
        logger.info("Fetching all accounts for userId: {}", userId);
        logger.debug("Processing request to retrieve accounts for userId: {}", userId);

        // Find all accounts by userId
        List<Account> accounts = accountRepository.findByUserId(userId);
        logger.info("Retrieved {} accounts for userId: {}", accounts.size(), userId);

        // Map account entities to summary DTOs
        List<AccountUserResponse.AccountSummary> accountSummaries = accounts.stream()
                .map(account -> new AccountUserResponse.AccountSummary(
                        account.getAccountId(),
                        account.getAccountNumber(),
                        account.getAccountType(),
                        account.getBalance(),
                        account.getCurrency(),
                        account.getIsActive(),
                        account.getIsLocked()))
                .collect(Collectors.toList());

        // Return response with list of accounts
        return new AccountUserResponse(accountSummaries);
    }

    @Override
    public AccountBalanceResponse getBalance(UUID accountId) {
        logger.info("Fetching balance for accountId: {}", accountId);
        logger.debug("Processing request to retrieve balance for accountId: {}", accountId);

        // Find account by ID
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> {
                    logger.error("Account not found with accountId: {}", accountId);
                    return new AccountServiceException(AccountErrorType.ACCOUNT_NOT_FOUND);
                });

        logger.info("Balance retrieved for accountId: {}", accountId);

        // Map account entity to balance response DTO
        return new AccountBalanceResponse(
                account.getAccountId(),
                account.getBalance(),
                account.getCurrency(),
                account.getUpdatedAt());
    }
}
