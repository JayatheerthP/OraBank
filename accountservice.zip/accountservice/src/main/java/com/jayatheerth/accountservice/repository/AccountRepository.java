package com.jayatheerth.accountservice.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jayatheerth.accountservice.entity.Account;

public interface AccountRepository extends JpaRepository<Account, UUID> {

    /**
     * Finds an account by account number.
     * 
     * @param accountNumber The unique account number.
     * @return An Optional containing the Account if found, empty otherwise.
     */
    Optional<Account> findByAccountNumber(String accountNumber);

    /**
     * Checks if an account exists with the given account number.
     * 
     * @param accountNumber The account number to check.
     * @return True if an account exists with the account number, false otherwise.
     */
    boolean existsByAccountNumber(String accountNumber);

    /**
     * Finds all accounts for a specific user.
     * 
     * @param userId The unique identifier of the user.
     * @return A list of Accounts associated with the user.
     */
    List<Account> findByUserId(UUID userId);
}