package com.jayatheerth.accountservice.controller;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jayatheerth.accountservice.dto.AccountBalanceResponse;
import com.jayatheerth.accountservice.dto.AccountCreateRequest;
import com.jayatheerth.accountservice.dto.AccountCreateResponse;
import com.jayatheerth.accountservice.dto.AccountResponse;
import com.jayatheerth.accountservice.dto.AccountUserResponse;
import com.jayatheerth.accountservice.service.AccountService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/accounts")
@AllArgsConstructor
public class AccountController {
    private static final Logger logger = LoggerFactory.getLogger(AccountController.class);
    private final AccountService accountService;

    /**
     * Endpoint for creating a new account.
     * Requires authentication.
     * 
     * @param request The account creation request containing account details.
     * @return ResponseEntity with AccountCreateResponse and HTTP status 201
     *         (Created).
     */
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<AccountCreateResponse> createAccount(@Valid @RequestBody AccountCreateRequest request) {
        logger.info("Received request to create account for userId: {}", request.getUserId());
        logger.debug("Account creation request details: type={}, currency={}, initialDeposit={}",
                request.getAccountType(), request.getCurrency(), request.getInitialDeposit());
        AccountCreateResponse response = accountService.createAccount(request);
        logger.info("Account created successfully with accountId: {} for userId: {}",
                response.getAccountId(), request.getUserId());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    /**
     * Endpoint to retrieve account details by ID.
     * Requires authentication.
     * 
     * @param accountId The unique identifier of the account.
     * @return ResponseEntity with AccountResponse and HTTP status 200 (OK).
     */
    @GetMapping("/{accountId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<AccountResponse> getAccount(@PathVariable UUID accountId) {
        logger.info("Received request to get account details for accountId: {}", accountId);
        AccountResponse response = accountService.getAccount(accountId);
        logger.debug("Returning account details for accountId: {}", accountId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Endpoint to retrieve all accounts for a specific user.
     * Requires authentication.
     * 
     * @param userId The unique identifier of the user.
     * @return ResponseEntity with AccountUserResponse and HTTP status 200 (OK).
     */
    @GetMapping("/user/{userId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<AccountUserResponse> getUserAccounts(@PathVariable UUID userId) {
        logger.info("Received request to get all accounts for userId: {}", userId);
        AccountUserResponse response = accountService.getUserAccounts(userId);
        logger.debug("Returning {} accounts for userId: {}", response.getAccounts().size(), userId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Endpoint to retrieve the balance of a specific account.
     * Requires authentication.
     * 
     * @param accountId The unique identifier of the account.
     * @return ResponseEntity with AccountBalanceResponse and HTTP status 200 (OK).
     */
    @GetMapping("/{accountId}/balance")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<AccountBalanceResponse> getBalance(@PathVariable UUID accountId) {
        logger.info("Received request to get balance for accountId: {}", accountId);
        AccountBalanceResponse response = accountService.getBalance(accountId);
        logger.debug("Returning balance for accountId: {}", accountId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
