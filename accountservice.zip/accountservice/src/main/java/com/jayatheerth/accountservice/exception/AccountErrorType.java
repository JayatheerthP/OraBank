package com.jayatheerth.accountservice.exception;

import org.springframework.http.HttpStatus;

public enum AccountErrorType {

    ACCOUNT_ALREADY_EXISTS("Account with this number already exists", HttpStatus.CONFLICT),
    ACCOUNT_NOT_FOUND("Account not found", HttpStatus.NOT_FOUND),
    USER_NOT_FOUND("User not found", HttpStatus.NOT_FOUND),
    INSUFFICIENT_BALANCE("Insufficient balance for operation", HttpStatus.BAD_REQUEST),
    ACCOUNT_LOCKED("Account is locked", HttpStatus.FORBIDDEN),
    INVALID_INPUT("Invalid input data", HttpStatus.BAD_REQUEST);

    private final String message;
    private final HttpStatus httpStatus;

    AccountErrorType(String message, HttpStatus httpStatus) {
        this.message = message;
        this.httpStatus = httpStatus;
    }

    public String getMessage() {
        return message;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}