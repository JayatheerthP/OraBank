package com.jayatheerth.accountservice.service;

import java.util.UUID;

import com.jayatheerth.accountservice.dto.AccountBalanceResponse;
import com.jayatheerth.accountservice.dto.AccountCreateRequest;
import com.jayatheerth.accountservice.dto.AccountCreateResponse;
import com.jayatheerth.accountservice.dto.AccountResponse;
import com.jayatheerth.accountservice.dto.AccountUserResponse;

public interface AccountService {

    /**
     * Creates a new account for a user with the provided details.
     * 
     * @param request The account creation request containing account details.
     * @return AccountCreateResponse containing the created account's information.
     */
    AccountCreateResponse createAccount(AccountCreateRequest request);

    /**
     * Retrieves detailed information about a specific account.
     * 
     * @param accountId The unique identifier of the account.
     * @return AccountResponse containing the account's detailed information.
     */
    AccountResponse getAccount(UUID accountId);

    /**
     * Retrieves all accounts associated with a specific user.
     * 
     * @param userId The unique identifier of the user.
     * @return AccountUserResponse containing a list of the user's accounts.
     */
    AccountUserResponse getUserAccounts(UUID userId);

    /**
     * Retrieves the balance information for a specific account.
     * 
     * @param accountId The unique identifier of the account.
     * @return AccountBalanceResponse containing the account's balance information.
     */
    AccountBalanceResponse getBalance(UUID accountId);
}
