package com.jayatheerth.accountservice.model;

public enum AccountType {
    SAVINGS,
    CURRENT,
    SALARY,
    FD,
    RD
}