package com.jayatheerth.accountservice.exception;

public class AccountServiceException extends RuntimeException {

    private final AccountErrorType errorType;

    public AccountServiceException(AccountErrorType errorType) {
        super(errorType.getMessage());
        this.errorType = errorType;
    }

    public AccountServiceException(AccountErrorType errorType, String customMessage) {
        super(customMessage);
        this.errorType = errorType;
    }

    public AccountErrorType getErrorType() {
        return errorType;
    }
}